'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Clock, Users, ChefHat, Utensils, Star } from 'lucide-react'

interface Meal {
  id: string
  type: string
  name: string
  description: string
  prepTime: number
  cookTime: number
  servings: number
  nutrition: {
    kcal: number
    protein: number
    carbs: number
    fat: number
  }
  difficulty: number
  appliances?: string[]
  preferredAppliance?: boolean
}

interface MealCardProps {
  meal: Meal
}

export function MealCard({ meal }: MealCardProps) {
  const getDifficultyLabel = (level: number) => {
    switch (level) {
      case 1: return 'Très facile'
      case 2: return 'Facile'
      case 3: return 'Moyen'
      case 4: return 'Difficile'
      default: return 'Inconnu'
    }
  }
  
  const getDifficultyColor = (level: number) => {
    switch (level) {
      case 1: return 'bg-green-100 text-green-800'
      case 2: return 'bg-blue-100 text-blue-800'
      case 3: return 'bg-yellow-100 text-yellow-800'
      case 4: return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }
  
  const getMealTypeLabel = (type: string) => {
    switch (type) {
      case 'breakfast': return 'Petit-déjeuner'
      case 'lunch': return 'Déjeuner'
      case 'dinner': return 'Dîner'
      case 'snack': return 'Collation'
      default: return type
    }
  }
  
  const getMealTypeIcon = (type: string) => {
    switch (type) {
      case 'breakfast': return <Utensils className="h-4 w-4" />
      case 'lunch': return <ChefHat className="h-4 w-4" />
      case 'dinner': return <ChefHat className="h-4 w-4" />
      case 'snack': return <Utensils className="h-4 w-4" />
      default: return <Utensils className="h-4 w-4" />
    }
  }
  
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 mb-2">
              {getMealTypeIcon(meal.type)}
              <Badge variant="outline">
                {getMealTypeLabel(meal.type)}
              </Badge>
            </div>
            <CardTitle className="text-lg">{meal.name}</CardTitle>
          </div>
          <Badge className={getDifficultyColor(meal.difficulty)}>
            {getDifficultyLabel(meal.difficulty)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-4">
          {meal.description}
        </p>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="flex items-center gap-2 text-sm">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span>{meal.prepTime + meal.cookTime} min</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span>{meal.servings} pers</span>
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-2 mb-4">
          <div className="text-center">
            <div className="text-xs text-muted-foreground">Calories</div>
            <div className="font-semibold">{meal.nutrition.kcal}</div>
          </div>
          <div className="text-center">
            <div className="text-xs text-muted-foreground">Protéines</div>
            <div className="font-semibold">{meal.nutrition.protein}g</div>
          </div>
          <div className="text-center">
            <div className="text-xs text-muted-foreground">Glucides</div>
            <div className="font-semibold">{meal.nutrition.carbs}g</div>
          </div>
          <div className="text-center">
            <div className="text-xs text-muted-foreground">Lipides</div>
            <div className="font-semibold">{meal.nutrition.fat}g</div>
          </div>
        </div>
        
        {/* Affichage des équipements */}
        {meal.appliances && meal.appliances.length > 0 && (
          <div className="mb-4">
            <div className="text-xs text-muted-foreground mb-2">Équipements utilisés:</div>
            <div className="flex flex-wrap gap-1">
              {meal.appliances.map((appliance, index) => (
                <Badge 
                  key={index} 
                  variant={meal.preferredAppliance && appliance === meal.appliances[0] ? "default" : "outline"}
                  className="text-xs"
                >
                  {appliance}
                  {meal.preferredAppliance && appliance === meal.appliances[0] && (
                    <Star className="h-3 w-3 ml-1 fill-current" />
                  )}
                </Badge>
              ))}
            </div>
          </div>
        )}
        
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="flex-1">
            Voir la recette
          </Button>
          <Button variant="outline" size="sm">
            Modifier
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}