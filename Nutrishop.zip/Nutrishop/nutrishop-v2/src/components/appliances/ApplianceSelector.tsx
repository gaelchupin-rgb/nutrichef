'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { ChefHat, Oven, Microwave, Toaster, Coffee, Blender, Wind, Cpu } from 'lucide-react'

interface Appliance {
  id: string
  name: string
  category: string
  icon: string
}

interface ApplianceSelectorProps {
  selectedAppliances: string[]
  preferredAppliance?: string
  onApplianceChange: (applianceId: string, selected: boolean) => void
  onPreferredChange: (applianceId: string) => void
}

const mockAppliances: Appliance[] = [
  { id: '1', name: 'Plaque induction', category: 'cuisson', icon: 'flame' },
  { id: '2', name: 'Four traditionnel', category: 'cuisson', icon: 'oven' },
  { id: '3', name: 'Four à micro-ondes', category: 'cuisson', icon: 'microwave' },
  { id: '4', name: 'Cookeo', category: 'cuisson', icon: 'chef-hat' },
  { id: '5', name: 'Air Fryer', category: 'cuisson', icon: 'wind' },
  { id: '6', name: 'Plaque vitrocéramique', category: 'cuisson', icon: 'flame' },
  { id: '7', name: 'Mixeur', category: 'préparation', icon: 'blender' },
  { id: '8', name: 'Robot culinaire', category: 'préparation', icon: 'cpu' },
  { id: '9', name: 'Friteuse', category: 'cuisson', icon: 'flame' },
  { id: '10', name: 'Vapeur', category: 'cuisson', icon: 'wind' },
]

const getIconComponent = (iconName: string) => {
  switch (iconName) {
    case 'flame': return <ChefHat className="h-6 w-6" />
    case 'oven': return <Oven className="h-6 w-6" />
    case 'microwave': return <Microwave className="h-6 w-6" />
    case 'chef-hat': return <ChefHat className="h-6 w-6" />
    case 'wind': return <Wind className="h-6 w-6" />
    case 'blender': return <Blender className="h-6 w-6" />
    case 'cpu': return <Cpu className="h-6 w-6" />
    default: return <ChefHat className="h-6 w-6" />
  }
}

export function ApplianceSelector({ 
  selectedAppliances, 
  preferredAppliance, 
  onApplianceChange, 
  onPreferredChange 
}: ApplianceSelectorProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  
  const categories = ['all', ...new Set(mockAppliances.map(a => a.category))]
  
  const filteredAppliances = selectedCategory === 'all' 
    ? mockAppliances 
    : mockAppliances.filter(a => a.category === selectedCategory)
  
  const isSelected = (applianceId: string) => selectedAppliances.includes(applianceId)
  
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-2">Vos équipements</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Sélectionnez les électroménagers dont vous disposez pour adapter les recettes.
        </p>
        
        <div className="flex gap-2 mb-4">
          {categories.map(category => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
            >
              {category === 'all' ? 'Tous' : category}
            </Button>
          ))}
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredAppliances.map(appliance => (
          <Card 
            key={appliance.id} 
            className={`cursor-pointer transition-colors ${
              isSelected(appliance.id) ? 'border-emerald-500 bg-emerald-50' : 'hover:bg-gray-50'
            }`}
            onClick={() => onApplianceChange(appliance.id, !isSelected(appliance.id))}
          >
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="text-emerald-600">
                    {getIconComponent(appliance.icon)}
                  </div>
                  <span className="text-sm font-medium">{appliance.name}</span>
                </div>
                {isSelected(appliance.id) && (
                  <div className="h-2 w-2 bg-emerald-500 rounded-full"></div>
                )}
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="text-xs">
                  {appliance.category}
                </Badge>
                {isSelected(appliance.id) && (
                  <Switch
                    checked={preferredAppliance === appliance.id}
                    onCheckedChange={(checked) => {
                      if (checked) onPreferredChange(appliance.id)
                    }}
                    onClick={(e) => e.stopPropagation()}
                  />
                )}
              </div>
              {preferredAppliance === appliance.id && (
                <div className="mt-2">
                  <Badge className="text-xs bg-emerald-100 text-emerald-800">
                    Privilégié
                  </Badge>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
      
      {selectedAppliances.length > 0 && (
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium mb-2">Équipements sélectionnés ({selectedAppliances.length})</h4>
          <div className="flex flex-wrap gap-2">
            {selectedAppliances.map(applianceId => {
              const appliance = mockAppliances.find(a => a.id === applianceId)
              return (
                <Badge 
                  key={applianceId} 
                  variant={preferredAppliance === applianceId ? "default" : "secondary"}
                  className="cursor-pointer"
                  onClick={() => onApplianceChange(applianceId, false)}
                >
                  {appliance?.name}
                  {preferredAppliance === applianceId && ' ⭐'}
                  <span className="ml-1">×</span>
                </Badge>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}