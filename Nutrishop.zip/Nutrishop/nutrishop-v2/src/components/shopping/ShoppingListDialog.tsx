'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Plus } from 'lucide-react'

interface ShoppingListDialogProps {
  planId?: string
}

export function ShoppingListDialog({ planId }: ShoppingListDialogProps) {
  const [open, setOpen] = useState(false)
  
  const handleCreateList = async () => {
    if (!planId) return
    
    try {
      // Logique pour sauvegarder la liste de courses
      console.log('Creating shopping list for plan:', planId)
      setOpen(false)
    } catch (error) {
      console.error('Error creating shopping list:', error)
    }
  }
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Créer une liste
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Créer une liste de courses</DialogTitle>
          <DialogDescription>
            Enregistrez votre liste de courses optimisée pour la consulter plus tard
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <p>
            Cette fonctionnalité va générer une liste de courses optimisée basée sur votre plan de repas,
            en tenant compte de vos préférences de magasins et de budget.
          </p>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Annuler
          </Button>
          <Button onClick={handleCreateList}>
            Enregistrer la liste
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}