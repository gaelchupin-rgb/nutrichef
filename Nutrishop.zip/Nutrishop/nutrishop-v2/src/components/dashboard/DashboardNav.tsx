'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { 
  LayoutDashboard, 
  Utensils, 
  ShoppingCart, 
  TrendingUp, 
  User,
  LogOut,
  ChefHat,
  Zap
} from 'lucide-react'
import { signOut } from 'next-auth/react'

const navItems = [
  {
    name: 'Tableau de bord',
    href: '/dashboard',
    icon: LayoutDashboard,
  },
  {
    name: 'Planification',
    href: '/dashboard/planner',
    icon: ChefHat,
  },
  {
    name: 'Nutrition',
    href: '/dashboard/nutrition',
    icon: TrendingUp,
  },
  {
    name: 'Courses',
    href: '/dashboard/shopping',
    icon: ShoppingCart,
  },
  {
    name: 'Profil',
    href: '/dashboard/profile',
    icon: User,
  },
]

export function DashboardNav() {
  const pathname = usePathname()

  return (
    <nav className="w-64 bg-white border-r border-gray-200 min-h-screen p-4">
      <div className="mb-8">
        <h1 className="text-xl font-bold text-emerald-600">NutriShop v2</h1>
      </div>
      
      <div className="space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          
          return (
            <Link key={item.href} href={item.href}>
              <Button
                variant={isActive ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start",
                  isActive && "bg-emerald-100 text-emerald-700 hover:bg-emerald-200"
                )}
              >
                <Icon className="mr-2 h-4 w-4" />
                {item.name}
              </Button>
            </Link>
          )
        })}
      </div>
      
      <div className="absolute bottom-4 left-4 right-4">
        <Button
          variant="ghost"
          className="w-full justify-start"
          onClick={() => signOut()}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Déconnexion
        </Button>
      </div>
    </nav>
  )
}