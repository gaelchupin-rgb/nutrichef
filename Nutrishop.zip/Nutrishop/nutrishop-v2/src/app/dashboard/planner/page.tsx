'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { MealCard } from '@/components/planner/MealCard'
import { ShoppingListDialog } from '@/components/shopping/ShoppingListDialog'
import { generateMealPlan } from '@/lib/gemini'
import { buildMealPlanPrompt } from '@/lib/prompts'
import { format, addDays, startOfWeek, endOfWeek } from 'date-fns'
import { fr } from 'date-fns/locale'
import { Loader2, CalendarDays, Utensils, ShoppingCart } from 'lucide-react'

interface Meal {
  id: string
  type: string
  name: string
  description: string
  prepTime: number
  cookTime: number
  servings: number
  nutrition: {
    kcal: number
    protein: number
    carbs: number
    fat: number
  }
  difficulty: number
  appliances?: string[]
  preferredAppliance?: boolean
}

interface DayPlan {
  date: string
  meals: Meal[]
}

export default function PlannerPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [mealPlan, setMealPlan] = useState<DayPlan[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [currentPlanId, setCurrentPlanId] = useState<string | null>(null)
  
  const handleGeneratePlan = async () => {
    if (!session) return
    
    setIsGenerating(true)
    try {
      const startDate = format(startOfWeek(selectedDate, { weekStartsOn: 1 }), 'yyyy-MM-dd')
      const endDate = format(endOfWeek(selectedDate, { weekStartsOn: 1 }), 'yyyy-MM-dd')
      
      // Get user profile (would normally fetch from API)
      const profile = {
        firstName: session.user?.name || '',
        lifestyle: 'CLASSIQUE',
        cookingLevel: 'BASES',
        goal: 'MAINTENIR',
        household: 2,
        dislikes: [],
        allergies: [],
        cuisineType: 'classique',
        kcalTarget: 2000,
        budget: 80,
        breakfastAppetite: 'NORMAL',
        lunchAppetite: 'NORMAL',
        dinnerAppetite: 'NORMAL',
        snackAppetite: 'LIGHT',
        appliances: [
          { appliance: { name: 'Plaque induction' }, preferred: false },
          { appliance: { name: 'Four traditionnel' }, preferred: true },
          { appliance: { name: 'Four à micro-ondes' }, preferred: false }
        ]
      }
      
      // Build prompt
      const prompt = buildMealPlanPrompt(profile, startDate, endDate)
      
      // Generate meal plan
      const plan = await generateMealPlan(prompt)
      setMealPlan(plan.days)
      
      // Save plan to database (would normally do this via API)
      const response = await fetch('/api/ai/generate-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ startDate, endDate })
      })
      
      if (response.ok) {
        const data = await response.json()
        setCurrentPlanId(data.planId)
      }
    } catch (error) {
      console.error('Error generating meal plan:', error)
    } finally {
      setIsGenerating(false)
    }
  }
  
  const selectedDayPlan = mealPlan.find(
    day => day.date === format(selectedDate, 'yyyy-MM-dd')
  )
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Planification de repas</h1>
          <p className="text-muted-foreground">
            Planifiez vos repas pour la semaine et générez automatiquement vos listes de courses
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleGeneratePlan} disabled={isGenerating}>
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Génération...
              </>
            ) : (
              <>
                <CalendarDays className="mr-2 h-4 w-4" />
                Générer un plan
              </>
            )}
          </Button>
          {currentPlanId && (
            <ShoppingListDialog planId={currentPlanId} />
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar */}
        <Card>
          <CardHeader>
            <CardTitle>Calendrier</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span>Semaine du</span>
                <span className="font-medium">
                  {format(startOfWeek(selectedDate, { weekStartsOn: 1 }), 'dd MMM', { locale: fr })}
                  {' - '}
                  {format(endOfWeek(selectedDate, { weekStartsOn: 1 }), 'dd MMM yyyy', { locale: fr })}
                </span>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => setSelectedDate(new Date())}
              >
                Aujourd'hui
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Day Plan */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>
                Repas du {format(selectedDate, 'EEEE d MMMM yyyy', { locale: fr })}
              </CardTitle>
              <CardDescription>
                {selectedDayPlan ? 'Votre plan pour la journée' : 'Aucun plan pour cette date'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {selectedDayPlan ? (
                <Tabs defaultValue="all" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="all">Tous</TabsTrigger>
                    <TabsTrigger value="breakfast">Petit-déj</TabsTrigger>
                    <TabsTrigger value="lunch">Déjeuner</TabsTrigger>
                    <TabsTrigger value="dinner">Dîner</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="all" className="space-y-4">
                    {selectedDayPlan.meals.map((meal) => (
                      <MealCard key={`${meal.type}-${meal.name}`} meal={meal} />
                    ))}
                  </TabsContent>
                  
                  {['breakfast', 'lunch', 'dinner'].map((mealType) => (
                    <TabsContent key={mealType} value={mealType} className="space-y-4">
                      {selectedDayPlan.meals
                        .filter(meal => meal.type === mealType)
                        .map(meal => (
                          <MealCard key={`${meal.type}-${meal.name}`} meal={meal} />
                        ))}
                    </TabsContent>
                  ))}
                </Tabs>
              ) : (
                <div className="text-center py-8">
                  <Utensils className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground mb-4">
                    Aucun repas planifié pour cette date
                  </p>
                  <Button onClick={handleGeneratePlan} disabled={isGenerating}>
                    Générer un plan pour cette semaine
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Weekly Overview */}
      {mealPlan.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Aperçu de la semaine</CardTitle>
            <CardDescription>
              Tous vos repas planifiés pour cette semaine
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {mealPlan.map((day) => (
                <div key={day.date} className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-2">
                    {format(new Date(day.date), 'EEEE d MMM', { locale: fr })}
                  </h3>
                  <div className="space-y-2">
                    {day.meals.slice(0, 3).map((meal) => (
                      <div key={`${day.date}-${meal.type}`} className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {meal.type === 'breakfast' ? 'PDJ' : 
                           meal.type === 'lunch' ? 'Déj' : 
                           meal.type === 'dinner' ? 'Dîn' : 'Coll'}
                        </Badge>
                        <span className="text-sm truncate">{meal.name}</span>
                      </div>
                    ))}
                    {day.meals.length > 3 && (
                      <div className="text-xs text-muted-foreground">
                        +{day.meals.length - 3} autres repas
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}