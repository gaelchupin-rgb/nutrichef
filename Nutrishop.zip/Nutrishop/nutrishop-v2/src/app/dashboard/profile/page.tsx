'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ApplianceSelector } from '@/components/appliances/ApplianceSelector'
import { User, Target, Settings, Bell, Shield, ChefHat } from 'lucide-react'

interface UserProfile {
  firstName: string
  lastName: string
  email: string
  username: string
  age?: number
  gender?: string
  height?: number
  weight?: number
  lifestyle: string
  cookingLevel: string
  dislikes: string[]
  allergies: string[]
  cuisineType: string
  breakfastAppetite: string
  lunchAppetite: string
  dinnerAppetite: string
  snackAppetite: string
  kcalTarget?: number
  proteinTarget?: number
  carbsTarget?: number
  fatTarget?: number
  goal: string
  radiusKm: number
  allowLocal: boolean
  location?: string
  maxStores: number
  budget?: number
  forcedDishes?: Record<string, number>
  appliances: Array<{
    id: string
    name: string
    preferred: boolean
  }>
}

const mockProfile: UserProfile = {
  firstName: 'Jean',
  lastName: 'Dupont',
  email: 'jean.dupont@example.com',
  username: 'jdupont',
  age: 35,
  gender: 'MALE',
  height: 175,
  weight: 70,
  lifestyle: 'CLASSIQUE',
  cookingLevel: 'BASES',
  dislikes: ['coriandre', 'foie'],
  allergies: ['noix', 'fruits de mer'],
  cuisineType: 'classique',
  breakfastAppetite: 'NORMAL',
  lunchAppetite: 'NORMAL',
  dinnerAppetite: 'NORMAL',
  snackAppetite: 'LIGHT',
  kcalTarget: 2000,
  proteinTarget: 150,
  carbsTarget: 250,
  fatTarget: 70,
  goal: 'MAINTENIR',
  radiusKm: 5,
  allowLocal: true,
  location: 'Paris, France',
  maxStores: 3,
  budget: 80,
  forcedDishes: {
    'croque-monsieur': 2,
    'pates': 3
  },
  appliances: [
    { id: '1', name: 'Plaque induction', preferred: false },
    { id: '2', name: 'Four traditionnel', preferred: true },
    { id: '3', name: 'Four à micro-ondes', preferred: false }
  ]
}

export default function ProfilePage() {
  const { data: session } = useSession()
  const [profile, setProfile] = useState<UserProfile>(mockProfile)
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('personal')
  
  // État pour les équipements
  const [selectedAppliances, setSelectedAppliances] = useState<string[]>(
    profile.appliances.map(a => a.id)
  )
  const [preferredAppliance, setPreferredAppliance] = useState<string | undefined>(
    profile.appliances.find(a => a.preferred)?.id
  )
  
  const handleApplianceChange = (applianceId: string, selected: boolean) => {
    if (selected) {
      setSelectedAppliances([...selectedAppliances, applianceId])
    } else {
      setSelectedAppliances(selectedAppliances.filter(id => id !== applianceId))
      if (preferredAppliance === applianceId) {
        setPreferredAppliance(undefined)
      }
    }
  }
  
  const handlePreferredChange = (applianceId: string) => {
    setPreferredAppliance(applianceId)
  }
  
  const handleUpdateProfile = async () => {
    setIsLoading(true)
    
    try {
      // Préparer les données des équipements
      const appliancesData = selectedAppliances.map(id => ({
        id,
        preferred: id === preferredAppliance
      }))
      
      // Simuler une mise à jour du profil
      await new Promise(resolve => setTimeout(resolve, 1000))
      console.log('Profile updated:', { ...profile, appliances: appliancesData })
    } catch (error) {
      console.error('Error updating profile:', error)
    } finally {
      setIsLoading(false)
    }
  }
  
  const handleAddDislike = () => {
    const newDislike = prompt('Ajouter un aliment à éviter:')
    if (newDislike && !profile.dislikes.includes(newDislike)) {
      setProfile({
        ...profile,
        dislikes: [...profile.dislikes, newDislike]
      })
    }
  }
  
  const handleRemoveDislike = (dislike: string) => {
    setProfile({
      ...profile,
      dislikes: profile.dislikes.filter(d => d !== dislike)
    })
  }
  
  const handleAddAllergy = () => {
    const newAllergy = prompt('Ajouter une allergie:')
    if (newAllergy && !profile.allergies.includes(newAllergy)) {
      setProfile({
        ...profile,
        allergies: [...profile.allergies, newAllergy]
      })
    }
  }
  
  const handleRemoveAllergy = (allergy: string) => {
    setProfile({
      ...profile,
      allergies: profile.allergies.filter(a => a !== allergy)
    })
  }
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Mon profil</h1>
        <p className="text-muted-foreground">
          Gérez vos informations personnelles et vos préférences
        </p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="personal">
            <User className="h-4 w-4 mr-2" />
            Informations
          </TabsTrigger>
          <TabsTrigger value="goals">
            <Target className="h-4 w-4 mr-2" />
            Objectifs
          </TabsTrigger>
          <TabsTrigger value="appliances">
            <ChefHat className="h-4 w-4 mr-2" />
            Équipements
          </TabsTrigger>
          <TabsTrigger value="preferences">
            <Settings className="h-4 w-4 mr-2" />
            Préférences
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="h-4 w-4 mr-2" />
            Sécurité
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="personal" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Informations personnelles</CardTitle>
              <CardDescription>
                Vos informations de base
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">Prénom</Label>
                  <Input
                    id="firstName"
                    value={profile.firstName}
                    onChange={(e) => setProfile({...profile, firstName: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Nom</Label>
                  <Input
                    id="lastName"
                    value={profile.lastName}
                    onChange={(e) => setProfile({...profile, lastName: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profile.email}
                    onChange={(e) => setProfile({...profile, email: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="username">Nom d'utilisateur</Label>
                  <Input
                    id="username"
                    value={profile.username}
                    onChange={(e) => setProfile({...profile, username: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="age">Âge</Label>
                  <Input
                    id="age"
                    type="number"
                    value={profile.age || ''}
                    onChange={(e) => setProfile({...profile, age: parseInt(e.target.value) || undefined})}
                  />
                </div>
                <div>
                  <Label htmlFor="gender">Genre</Label>
                  <Select value={profile.gender} onValueChange={(value) => setProfile({...profile, gender: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionnez" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MALE">Homme</SelectItem>
                      <SelectItem value="FEMALE">Femme</SelectItem>
                      <SelectItem value="OTHER">Autre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="height">Taille (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    value={profile.height || ''}
                    onChange={(e) => setProfile({...profile, height: parseInt(e.target.value) || undefined})}
                  />
                </div>
                <div>
                  <Label htmlFor="weight">Poids (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    value={profile.weight || ''}
                    onChange={(e) => setProfile({...profile, weight: parseInt(e.target.value) || undefined})}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Préférences alimentaires</CardTitle>
              <CardDescription>
                Vos goûts et restrictions alimentaires
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="lifestyle">Mode de vie</Label>
                  <Select value={profile.lifestyle} onValueChange={(value) => setProfile({...profile, lifestyle: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ECONOME">Économe</SelectItem>
                      <SelectItem value="CLASSIQUE">Classique</SelectItem>
                      <SelectItem value="BON_VIVANT">Bon vivant</SelectItem>
                      <SelectItem value="VEGETARIEN">Végétarien</SelectItem>
                      <SelectItem value="VEGAN">Vegan</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="cookingLevel">Niveau de cuisine</Label>
                  <Select value={profile.cookingLevel} onValueChange={(value) => setProfile({...profile, cookingLevel: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DEBUTANT">Débutant</SelectItem>
                      <SelectItem value="BASES">J'ai des bases</SelectItem>
                      <SelectItem value="BON">Je suis bon</SelectItem>
                      <SelectItem value="CHEF">Un vrai chef !</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="cuisineType">Type de cuisine préféré</Label>
                  <Select value={profile.cuisineType} onValueChange={(value) => setProfile({...profile, cuisineType: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="classique">Classique</SelectItem>
                      <SelectItem value="batch">Batch cooking</SelectItem>
                      <SelectItem value="light">Léger</SelectItem>
                      <SelectItem value="sport">Sport</SelectItem>
                      <SelectItem value="mediterraneen">Méditerranéen</SelectItem>
                      <SelectItem value="asiatique">Asiatique</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="goal">Objectif</Label>
                  <Select value={profile.goal} onValueChange={(value) => setProfile({...profile, goal: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PERDRE">Perdre du poids</SelectItem>
                      <SelectItem value="MAINTENIR">Maintenir mon poids</SelectItem>
                      <SelectItem value="PRENDRE">Prendre du poids</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label>Aliments à éviter</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {profile.dislikes.map((dislike) => (
                    <Badge key={dislike} variant="secondary" className="cursor-pointer" onClick={() => handleRemoveDislike(dislike)}>
                      {dislike} ×
                    </Badge>
                  ))}
                  <Badge variant="outline" className="cursor-pointer" onClick={handleAddDislike}>
                    + Ajouter
                  </Badge>
                </div>
              </div>
              
              <div>
                <Label>Allergies</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {profile.allergies.map((allergy) => (
                    <Badge key={allergy} variant="destructive" className="cursor-pointer" onClick={() => handleRemoveAllergy(allergy)}>
                      {allergy} ×
                    </Badge>
                  ))}
                  <Badge variant="outline" className="cursor-pointer" onClick={handleAddAllergy}>
                    + Ajouter
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="goals" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Objectifs nutritionnels</CardTitle>
              <CardDescription>
                Définissez vos cibles quotidiennes
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="kcalTarget">Calories (kcal/jour)</Label>
                  <Input
                    id="kcalTarget"
                    type="number"
                    value={profile.kcalTarget || ''}
                    onChange={(e) => setProfile({...profile, kcalTarget: parseInt(e.target.value) || undefined})}
                  />
                </div>
                <div>
                  <Label htmlFor="proteinTarget">Protéines (g/jour)</Label>
                  <Input
                    id="proteinTarget"
                    type="number"
                    value={profile.proteinTarget || ''}
                    onChange={(e) => setProfile({...profile, proteinTarget: parseInt(e.target.value) || undefined})}
                  />
                </div>
                <div>
                  <Label htmlFor="carbsTarget">Glucides (g/jour)</Label>
                  <Input
                    id="carbsTarget"
                    type="number"
                    value={profile.carbsTarget || ''}
                    onChange={(e) => setProfile({...profile, carbsTarget: parseInt(e.target.value) || undefined})}
                  />
                </div>
                <div>
                  <Label htmlFor="fatTarget">Lipides (g/jour)</Label>
                  <Input
                    id="fatTarget"
                    type="number"
                    value={profile.fatTarget || ''}
                    onChange={(e) => setProfile({...profile, fatTarget: parseInt(e.target.value) || undefined})}
                  />
                </div>
              </div>
              
              <div className="pt-4 border-t">
                <h3 className="font-medium mb-2">Recommandations automatiques</h3>
                <div className="text-sm text-muted-foreground">
                  {profile.height && profile.weight && profile.age && profile.goal && (
                    <p>
                      Basé sur vos informations (âge: {profile.age}, taille: {profile.height}cm, poids: {profile.weight}kg),
                      nous recommandons environ {Math.round(profile.weight * 25)} calories par jour pour votre objectif de {profile.goal.toLowerCase()}.
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Appétit par repas</CardTitle>
              <CardDescription>
                Ajustez les portions selon votre appétit
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="breakfastAppetite">Petit-déjeuner</Label>
                  <Select value={profile.breakfastAppetite} onValueChange={(value) => setProfile({...profile, breakfastAppetite: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="NONE">Aucun</SelectItem>
                      <SelectItem value="LIGHT">Léger</SelectItem>
                      <SelectItem value="NORMAL">Normal</SelectItem>
                      <SelectItem value="HEAVY">Copieux</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="lunchAppetite">Déjeuner</Label>
                  <Select value={profile.lunchAppetite} onValueChange={(value) => setProfile({...profile, lunchAppetite: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="NONE">Aucun</SelectItem>
                      <SelectItem value="LIGHT">Léger</SelectItem>
                      <SelectItem value="NORMAL">Normal</SelectItem>
                      <SelectItem value="HEAVY">Copieux</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="dinnerAppetite">Dîner</Label>
                  <Select value={profile.dinnerAppetite} onValueChange={(value) => setProfile({...profile, dinnerAppetite: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="NONE">Aucun</SelectItem>
                      <SelectItem value="LIGHT">Léger</SelectItem>
                      <SelectItem value="NORMAL">Normal</SelectItem>
                      <SelectItem value="HEAVY">Copieux</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="snackAppetite">Collation</Label>
                  <Select value={profile.snackAppetite} onValueChange={(value) => setProfile({...profile, snackAppetite: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="NONE">Aucune</SelectItem>
                      <SelectItem value="LIGHT">Léger</SelectItem>
                      <SelectItem value="NORMAL">Normal</SelectItem>
                      <SelectItem value="HEAVY">Copieux</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="appliances" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Équipements de cuisine</CardTitle>
              <CardDescription>
                Sélectionnez les électroménagers dont vous disposez et indiquez celui que vous préférez utiliser
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ApplianceSelector
                selectedAppliances={selectedAppliances}
                preferredAppliance={preferredAppliance}
                onApplianceChange={handleApplianceChange}
                onPreferredChange={handlePreferredChange}
              />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="preferences" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Préférences de courses</CardTitle>
              <CardDescription>
                Configurez vos habitudes de shopping
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="location">Localisation</Label>
                  <Input
                    id="location"
                    value={profile.location || ''}
                    onChange={(e) => setProfile({...profile, location: e.target.value})}
                    placeholder="Votre adresse ou ville"
                  />
                </div>
                <div>
                  <Label htmlFor="radiusKm">Rayon de recherche (km)</Label>
                  <Input
                    id="radiusKm"
                    type="number"
                    min="1"
                    max="50"
                    value={profile.radiusKm}
                    onChange={(e) => setProfile({...profile, radiusKm: parseInt(e.target.value) || 5})}
                  />
                </div>
                <div>
                  <Label htmlFor="maxStores">Nombre maximum de magasins</Label>
                  <Input
                    id="maxStores"
                    type="number"
                    min="1"
                    max="5"
                    value={profile.maxStores}
                    onChange={(e) => setProfile({...profile, maxStores: parseInt(e.target.value) || 3})}
                  />
                </div>
                <div>
                  <Label htmlFor="budget">Budget hebdomadaire (€)</Label>
                  <Input
                    id="budget"
                    type="number"
                    min="0"
                    value={profile.budget || ''}
                    onChange={(e) => setProfile({...profile, budget: parseFloat(e.target.value) || undefined})}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Plats imposés</CardTitle>
              <CardDescription>
                Plats que vous souhaitez inclure régulièrement dans vos plans
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {profile.forcedDishes && Object.entries(profile.forcedDishes).map(([dish, frequency]) => (
                  <div key={dish} className="flex justify-between items-center p-2 border rounded">
                    <span>{dish}</span>
                    <span>{frequency} fois par mois</span>
                  </div>
                ))}
                <Button variant="outline" size="sm">
                  + Ajouter un plat
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Préférences de notification</CardTitle>
              <CardDescription>
                Gérez les notifications que vous recevez
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Rappels de repas</div>
                  <div className="text-sm text-muted-foreground">
                    Recevez des notifications pour enregistrer vos repas
                  </div>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Suggestions de recettes</div>
                  <div className="text-sm text-muted-foreground">
                    Recevez des recommandations basées sur vos préférences
                  </div>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Alertes promotions</div>
                  <div className="text-sm text-muted-foreground">
                    Soyez notifié des promotions dans vos magasins préférés
                  </div>
                </div>
                <Switch />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Résumé hebdomadaire</div>
                  <div className="text-sm text-muted-foreground">
                    Recevez un résumé de votre semaine nutritionnelle
                  </div>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sécurité du compte</CardTitle>
              <CardDescription>
                Gérez la sécurité de votre compte
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="current-password">Mot de passe actuel</Label>
                <Input id="current-password" type="password" />
              </div>
              
              <div>
                <Label htmlFor="new-password">Nouveau mot de passe</Label>
                <Input id="new-password" type="password" />
              </div>
              
              <div>
                <Label htmlFor="confirm-password">Confirmer le mot de passe</Label>
                <Input id="confirm-password" type="password" />
              </div>
              
              <Button>Changer le mot de passe</Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Connexions</CardTitle>
              <CardDescription>
                Gérez les appareils connectés à votre compte
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 border rounded">
                  <div>
                    <div className="font-medium">Chrome sur Windows</div>
                    <div className="text-sm text-muted-foreground">Paris, France • Actif maintenant</div>
                  </div>
                  <Badge variant="outline">Appareil actuel</Badge>
                </div>
                
                <div className="flex justify-between items-center p-3 border rounded">
                  <div>
                    <div className="font-medium">Safari sur iPhone</div>
                    <div className="text-sm text-muted-foreground">Paris, France • Il y a 2 jours</div>
                  </div>
                  <Button variant="outline" size="sm">Déconnecter</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="flex justify-end">
        <Button onClick={handleUpdateProfile} disabled={isLoading}>
          {isLoading ? 'Enregistrement...' : 'Enregistrer les modifications'}
        </Button>
      </div>
    </div>
  )
}