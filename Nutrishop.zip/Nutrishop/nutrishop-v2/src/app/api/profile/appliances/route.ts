import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { appliances } = await request.json()
    
    // Récupérer le profil
    const profile = await prisma.profile.findUnique({
      where: { userId: session.user.id }
    })
    
    if (!profile) {
      return NextResponse.json({ error: 'Profile not found' }, { status: 404 })
    }
    
    // Supprimer les équipements existants
    await prisma.profileAppliance.deleteMany({
      where: { profileId: profile.id }
    })
    
    // Ajouter les nouveaux équipements
    for (const appliance of appliances) {
      await prisma.profileAppliance.create({
        data: {
          profileId: profile.id,
          applianceId: appliance.id,
          preferred: appliance.preferred || false
        }
      })
    }
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error updating appliances:', error)
    return NextResponse.json(
      { error: 'Failed to update appliances' },
      { status: 500 }
    )
  }
}