import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { generateMealPlan } from '@/lib/gemini'
import { buildMealPlanPrompt } from '@/lib/prompts'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { startDate, endDate } = await req.json()
    
    // Get user profile
    const profile = await prisma.profile.findUnique({
      where: { userId: session.user.id },
      include: {
        appliances: {
          include: {
            appliance: true
          }
        }
      }
    })
    
    if (!profile) {
      return NextResponse.json({ error: 'Profile not found' }, { status: 404 })
    }

    // Build prompt
    const prompt = buildMealPlanPrompt(profile, startDate, endDate)
    
    // Generate meal plan
    const mealPlan = await generateMealPlan(prompt)
    
    // Save plan to database
    const plan = await prisma.plan.create({
      data: {
        userId: session.user.id,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
      }
    })
    
    // Save menu items
    for (const day of mealPlan.days) {
      for (const meal of day.meals) {
        // Create or get recipe
        let recipe = await prisma.recipe.findFirst({
          where: { name: meal.name }
        })
        
        if (!recipe) {
          recipe = await prisma.recipe.create({
            data: {
              name: meal.name,
              description: meal.description,
              instructions: meal.instructions.join('\n'),
              prepTime: meal.prepTime,
              cookTime: meal.cookTime,
              servings: meal.servings,
              difficulty: meal.difficulty,
              kcal: meal.nutrition.kcal,
              protein: meal.nutrition.protein,
              carbs: meal.nutrition.carbs,
              fat: meal.nutrition.fat,
              fiber: meal.nutrition.fiber,
              sugar: meal.nutrition.sugar,
              sodium: meal.nutrition.sodium,
              tags: [profile.cuisineType || 'classique'],
              category: meal.type,
            }
          })
        }
        
        // Create menu item
        await prisma.menuItem.create({
          data: {
            planId: plan.id,
            date: new Date(day.date),
            mealType: meal.type,
            recipeId: recipe.id,
          }
        })
      }
    }
    
    return NextResponse.json({ 
      success: true, 
      planId: plan.id,
      mealPlan 
    })
  } catch (error) {
    console.error('Error generating meal plan:', error)
    return NextResponse.json(
      { error: 'Failed to generate meal plan' },
      { status: 500 }
    )
  }
}