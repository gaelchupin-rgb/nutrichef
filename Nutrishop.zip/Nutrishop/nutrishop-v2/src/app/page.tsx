import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ChefHat, ShoppingCart, TrendingUp, Utensils, Zap } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            NutriShop v2
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Planifiez vos repas, suivez votre nutrition et optimisez vos courses 
            pour une vie plus saine et économique.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/(auth)/register">
              <Button size="lg" className="w-full sm:w-auto">
                Commencer gratuitement
              </Button>
            </Link>
            <Link href="/(auth)/login">
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                Se connecter
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6 mb-16">
          <Card>
            <CardHeader>
              <ChefHat className="h-12 w-12 text-emerald-600 mb-4" />
              <CardTitle>Planification de repas</CardTitle>
              <CardDescription>
                Générez des plans de repas personnalisés selon vos préférences et vos équipements.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <TrendingUp className="h-12 w-12 text-emerald-600 mb-4" />
              <CardTitle>Suivi nutritionnel</CardTitle>
              <CardDescription>
                Suivez vos apports nutritionnels et atteignez vos objectifs santé.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <ShoppingCart className="h-12 w-12 text-emerald-600 mb-4" />
              <CardTitle>Optimisation des courses</CardTitle>
              <CardDescription>
                Comparez les prix et trouvez les meilleures offres dans les magasins proches.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <Utensils className="h-12 w-12 text-emerald-600 mb-4" />
              <CardTitle>Recettes personnalisées</CardTitle>
              <CardDescription>
                Découvrez des recettes adaptées à vos goûts et votre niveau de cuisine.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <Zap className="h-12 w-12 text-emerald-600 mb-4" />
              <CardTitle>Équipements intelligents</CardTitle>
              <CardDescription>
                Adaptez les recettes à vos électroménagers et privilégiez vos appareils préférés.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Prêt à transformer votre alimentation ?
          </h2>
          <p className="text-gray-600 mb-8">
            Rejoignez des milliers d'utilisateurs qui ont déjà amélioré leur santé et leur budget.
          </p>
          <Link href="/(auth)/register">
            <Button size="lg">
              Créer mon compte
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}