import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Créer les équipements de base
  const appliances = [
    { name: 'Plaque induction', category: 'cuisson', icon: 'flame' },
    { name: 'Four traditionnel', category: 'cuisson', icon: 'oven' },
    { name: 'Four à micro-ondes', category: 'cuisson', icon: 'microwave' },
    { name: 'Cookeo', category: 'cuisson', icon: 'chef-hat' },
    { name: 'Air Fryer', category: 'cuisson', icon: 'wind' },
    { name: 'Plaque vitrocéramique', category: 'cuisson', icon: 'flame' },
    { name: 'Mixeur', category: 'préparation', icon: 'blender' },
    { name: 'Robot culinaire', category: 'préparation', icon: 'cpu' },
    { name: 'Friteuse', category: 'cuisson', icon: 'flame' },
    { name: 'Vapeur', category: 'cuisson', icon: 'wind' },
  ]

  for (const appliance of appliances) {
    await prisma.appliance.upsert({
      where: { name: appliance.name },
      update: {},
      create: appliance
    })
  }

  console.log('Équipements initialisés avec succès!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })