export function buildMealPlanPrompt(profile: any, startDate: string, endDate: string) {
  // Récupérer les équipements et l'équipement préféré
  const appliances = profile.appliances?.map((pa: any) => pa.appliance.name) || []
  const preferredAppliance = profile.appliances?.find((pa: any) => pa.preferred)?.appliance.name
  
  return `
    Tu es un nutritionniste et chef expérimenté. Génère un plan de repas personnalisé 
    pour la période du ${startDate} au ${endDate}.
    
    Profil utilisateur:
    - Nom: ${profile.firstName || ''}
    - Mode de vie: ${profile.lifestyle}
    - Niveau de cuisine: ${profile.cookingLevel}
    - Objectif: ${profile.goal}
    - Nombre de personnes: ${profile.household}
    - Aliments à éviter: ${profile.dislikes?.join(', ') || 'aucun'}
    - Allergies: ${profile.allergies?.join(', ') || 'aucune'}
    - Type de cuisine préféré: ${profile.cuisineType || 'classique'}
    ${profile.kcalTarget ? `- Cibles caloriques: ${profile.kcalTarget} kcal/jour` : ''}
    ${profile.budget ? `- Budget: ${profile.budget}€/semaine` : ''}
    
    Équipements disponibles:
    ${appliances.length > 0 ? `- Appareils disponibles: ${appliances.join(', ')}` : '- Aucun équipement spécifié'}
    ${preferredAppliance ? `- Appareil privilégié: ${preferredAppliance} (à privilégier dans les recettes)` : ''}
    
    Appétit par repas:
    - Petit-déjeuner: ${profile.breakfastAppetite || 'NORMAL'}
    - Déjeuner: ${profile.lunchAppetite || 'NORMAL'}
    - Dîner: ${profile.dinnerAppetite || 'NORMAL'}
    - Collation: ${profile.snackAppetite || 'LIGHT'}
    
    Contraintes supplémentaires:
    - Inclure des recettes adaptées au niveau de cuisine
    - Varier les repas et éviter les répétitions
    - Proposer des options équilibrées nutritionnellement
    - Tenir compte des préférences et contraintes budgétaires
    ${appliances.length > 0 ? '- Adapter les recettes aux équipements disponibles' : ''}
    ${preferredAppliance ? '- Privilégier les recettes utilisant le ${preferredAppliance} lorsque c\'est possible' : ''}
    
    Réponds au format JSON avec la structure suivante:
    {
      "days": [
        {
          "date": "YYYY-MM-DD",
          "meals": [
            {
              "type": "petit-déjeuner|déjeuner|dîner|collation",
              "name": "Nom du plat",
              "description": "Description courte",
              "prepTime": minutes,
              "cookTime": minutes,
              "servings": nombre,
              "ingredients": [
                {"name": "ingrédient", "quantity": nombre, "unit": "unité"}
              ],
              "instructions": ["étape 1", "étape 2", ...],
              "nutrition": {
                "kcal": nombre,
                "protein": nombre,
                "carbs": nombre,
                "fat": nombre,
                "fiber": nombre,
                "sugar": nombre,
                "sodium": nombre
              },
              "difficulty": 1-4,
              "appliances": ["appareil utilisé 1", "appareil utilisé 2"],
              "preferredAppliance": true/false // si la recette utilise l'appareil privilégié
            }
          ]
        }
      ]
    }
  `
}